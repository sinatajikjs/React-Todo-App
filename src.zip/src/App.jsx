import TodoApp from './components/TodoApp/TodoApp';
const App = () => {
  return <TodoApp/>;
};

export default App;
